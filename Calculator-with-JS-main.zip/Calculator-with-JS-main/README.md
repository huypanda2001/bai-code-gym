# Build calculator with JS
Bao gồm những chức năng như: 
+ Thực hiện các phép tính toán cơ bản 
+ Dark & Light Mode
+ Xem lại lịch sử tính toán
